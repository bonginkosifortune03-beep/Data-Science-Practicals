#________________________________________________________
# The code below is adapted from:
# https://rpubs.com/mstefan-rpubs/maze1
#________________________________________________________

  initialiseMaze <- function(n, m){
  
    maze <- list()
  
    for(i in 1:n){
      
        for(j in 1:m){
      
          cell <- list(i = i, j = j,
                       visited = FALSE,
                       up    = TRUE,
                       down  = TRUE,
                       left  = TRUE,
                       right = TRUE)
      
         maze[[length(maze) + 1]] <- cell
     }
    }
  
  return(maze)
  
  }

  findNeighbor   <- function(maze,index) {
  
    cell <- maze[[index]]
  #-----------------------------------------------------
  # Determine rows and columns of all cells in the maze
  #-----------------------------------------------------
    
    rows <- sapply(maze, FUN = function(cell) cell$i)
    cols <- sapply(maze, FUN = function(cell) cell$j)
   
  #-----------------------------------------------------
  # Determine neighbor candidates
  #-----------------------------------------------------
    
    above <- which(rows == (cell$i + 1) & cols == cell$j)
    below <- which(rows == (cell$i - 1) & cols == cell$j)
    left  <- which(cols == (cell$j - 1) & rows == cell$i)
    right <- which(cols == (cell$j + 1) & rows == cell$i)
    
    candidates <- c(above, below, left, right)
  
  #-----------------------------------------------------
  # Neighbors must be unvisited
  #-----------------------------------------------------
    
    visited   <- sapply(maze[candidates], FUN = function(cell) cell$visited)
    neighbors <- candidates[!visited]

  #-----------------------------------------------------
  # return
  #-----------------------------------------------------
    
    if (length(neighbors) == 0) {         # no suitable candidates
      return(NA)
    } else if (length(neighbors) == 1) {  # exactly one candidate
      return(neighbors)
    } else {                              # multiple candidates 
      return(sample(neighbors,1))       
    }
}

  removeWalls    <- function(maze, a, b) {
  
  #-------------------------------------------------------------------  
  # a over b
  #-------------------------------------------------------------------  
    
    if (maze[[a]]$i == maze[[b]]$i + 1 & maze[[a]]$j == maze[[b]]$j) {
      maze[[a]]$down <- FALSE
      maze[[b]]$up <- FALSE
    }
    
  #-------------------------------------------------------------------  
  # a under b
  #-------------------------------------------------------------------  
    
    if (maze[[a]]$i == maze[[b]]$i - 1 & maze[[a]]$j == maze[[b]]$j) {
      maze[[a]]$up <- FALSE
      maze[[b]]$down <- FALSE
    }
    
  #-------------------------------------------------------------------  
  # a left of b
  #-------------------------------------------------------------------  
    
    if (maze[[a]]$j == maze[[b]]$j - 1 & maze[[a]]$i == maze[[b]]$i) {
      maze[[a]]$right <- FALSE
      maze[[b]]$left <- FALSE
    }
    
  #-------------------------------------------------------------------  
  # a right of b
  #-------------------------------------------------------------------  
    
    if (maze[[a]]$j == maze[[b]]$j + 1 & maze[[a]]$i == maze[[b]]$i) {
      maze[[a]]$left <- FALSE
      maze[[b]]$right <- FALSE
    }
  
  return(maze)
  
}

  generateMaze   <- function(n, m, seed.Value){
  
    set.seed(seed.Value)
    maze <- initialiseMaze(n, m)
      
    stack   <- c(current <- 1)
    
    #------------------------------------------------
    # create maze using recursive backtracking
    #------------------------------------------------
  
     while (length(stack) > 0) {
    
    #------------------------------------------------
    # Mark current cell as visited and find neighbors
    #------------------------------------------------
      
      maze[[current]]$visited <- TRUE
      neighbor <- findNeighbor(maze, current)
    
    #------------------------------------------------
    # remove walls, update stack and update current 
    #  OR backtrack
    #------------------------------------------------
      
      if (!is.na(neighbor)) {
        
        maze    <- removeWalls(maze, current, neighbor)
        stack   <- c(stack, neighbor)
        current <- neighbor
        
      } else {
        
        stack   <- stack[0:(length(stack)-1)]
        current <- stack[length(stack)]
      }
    } 
    
    return(maze)
  }

  showMaze       <- function(maze, n, m) {
  
  d <- max(n,m)
  # background
  par(mar = rep(1,4), bg = "burlywood1", bty = "n")
  plot(rep(0,d+1) ~ c(0:d), type = "l", asp = 1,
       ylim = c(0,d), xlim = c(0,d),
       yaxt = "n", xaxt = "n",
       ylab = "", xlab = "")
  
  # highlight visited areas
  for (idx in 1:(n*m)) {
    i <- maze[[idx]]$i
    j <- maze[[idx]]$j
    if (maze[[idx]]$visited) rect(j-1, i-1, j, i, col = "deepskyblue3", lty = 0)
  }
  
  # draw walls
  for (idx in 1:(n*m)) {
    i <- maze[[idx]]$i
    j <- maze[[idx]]$j  
    if (maze[[idx]]$up) lines( rep(i,2) ~ c(j-1,j), col="white", lwd=4)
    if (maze[[idx]]$down) lines( rep(i-1,2) ~ c(j-1,j), col="white", lwd=4)
    if (maze[[idx]]$right) lines( c(i-1,i) ~ rep(j,2), col="white", lwd=4)
    if (maze[[idx]]$left) lines( c(i-1,i) ~ rep(j-1,2), col="white", lwd=4)
  }
  
  }
  
  