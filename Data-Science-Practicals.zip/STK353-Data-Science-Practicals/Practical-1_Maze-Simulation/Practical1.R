#################################################################
# Assignment 1
# Name and surname: Maima Bonginkosi Fortune
# Student number: 22826093
#################################################################

#-------------------------------------------------------------------------------
# Set the working directory to the folder on your computer that contains the 
# the "maze_generation.R" file and the run the code in line 8 below. Running the 
# code in line 8 will load all the functions defined in the R script into 
# your R environment and allow you to call the generateMaze() function.
#-------------------------------------------------------------------------------
 
  source("maze_generation.R")

#-------------------------------------------------------------------------------
# Loading the relevant packages and importing the file for Question 3
#-------------------------------------------------------------------------------

  library(ggplot2)

  strategies <- read.csv("Maze_strategies.csv")

#-------------------------------------------------------------------------------
# Question 1 (a)
#-------------------------------------------------------------------------------
  
Maze<- generateMaze(25,25,345)
#showMaze(Maze,25,25)
  
  
  
#-------------------------------------------------------------------------------
# Question 1 (b)
#-------------------------------------------------------------------------------
#index = (row - 1) * number_of_columns + column  
start_index<-(9-1)*25+17;
 
  

#-------------------------------------------------------------------------------
# Question 2 (a)
#-------------------------------------------------------------------------------
#str(Maze)
  
#This gives the orintation of the right hand rule;
  orientation <-function(cell,direction){
    switch(direction,
           "up"=list(forward=cell$up,
                     backward=cell$down,
                     left=cell$left,
                     right=cell$right),
           
           "right"=list(forward=cell$right,
                        backward= cell$left,
                        left=cell$up,
                        right=cell$down),
           "down" = list(forward  = cell$down,
                         backward = cell$up,
                         left     = cell$right,
                         right    = cell$left),
           
           "left"  = list(forward  = cell$left,
                          backward = cell$right,
                          left     = cell$down,
                          right    = cell$up))
  }
  
#Then we need to create the rotation directions using right hand rule
  rotate90cw <-function(direction){
    c("up"="right", "right" = "down", "down" = "left", "left" = "up")[direction]
  }
  
#Then rotate counter clockwise
  rotate90ccw<-function(direction){
    c("up" = "left", "right" = "up", "down" = "right", "left" = "down")[direction]
  }
#Then we need to create movements in the given direction;
move_forward<-function(cell, direction){
  switch(direction,
         "up"=c(cell$i+1,cell$j),    #for going up in row cell
         "right"=c(cell$i,cell$j+1),  #for going forward right
         "down"=c(cell$i-1,cell$j),  #for going down the cell
         "left"=c(cell$i,cell$j-1))
}  

#then create an action based on the current direction and right hand rule
action <- function(cell, direction, Maze) {
  orient <- orientation(cell, direction)
  
  if (!isTRUE(orient$right) && isTRUE(orient$forward)) {
    
    redirect <- rotate90cw(direction)
    new_pos <- move_forward(cell, redirect)
    
  } else if (isTRUE(orient$right) && !isTRUE(orient$forward)) {
    
    redirect <- direction
    new_pos <- move_forward(cell, redirect)
    
  } else if (isTRUE(orient$right) && isTRUE(orient$forward)) {
    
    redirect <- rotate90ccw(direction)
    new_pos <- cell
    
  } else {
    
    redirect <- rotate90cw(direction)
    new_pos <- move_forward(cell, redirect)
  }  
  
  new_idx <- which(sapply(Maze, function(c) c$i == new_pos[1] && c$j == new_pos[2]))
  return(list(new_idx, redirect))
}

#Then we need to set the start and end index
start_index1 <- which(sapply(Maze, function(cell) cell$i == 13 && cell$j == 13))
end_index   <- which(sapply(Maze, function(cell) cell$i == 1 && cell$j == 1))

#Then we need to initialize the solver using the right hand rule
getOut<-action(Maze[[start_index1]],"right",Maze)
solver_right<-c(start_index1)
l<-1

while (getOut[[1]] != end_index) {
  current_idx <- getOut[[1]]
  current_dir <- getOut[[2]]
  
  solver_right <- c(solver_right, current_idx)
  getOut <- action(Maze[[current_idx]], current_dir, Maze)
}

#We then need to include the end position
solver_right<-c(solver_right, end_index)







#-------------------------------------------------------------------------------
# Question 2 (b)
# Left-hand rule orientation
orientation <- function(cell, direction) {
  switch(direction,
         "up" = list(forward = cell$up,
                     backward = cell$down,
                     left = cell$left,
                     right = cell$right),
         
         "right" = list(forward = cell$right,
                        backward = cell$left,
                        left = cell$up,
                        right = cell$down),
         
         "down" = list(forward = cell$down,
                       backward = cell$up,
                       left = cell$right,
                       right = cell$left),
         
         "left" = list(forward = cell$left,
                       backward = cell$right,
                       left = cell$down,
                       right = cell$up))
}

# Rotations
rotate90cw <- function(direction) {
  c("up" = "right", "right" = "down", "down" = "left", "left" = "up")[direction]
}

rotate90ccw <- function(direction) {
  c("up" = "left", "left" = "down", "down" = "right", "right" = "up")[direction]
}

# Move in given direction
move_forward <- function(cell, direction) {
  switch(direction,
         "up" = c(cell$i + 1, cell$j),
         "right" = c(cell$i, cell$j + 1),
         "down" = c(cell$i - 1, cell$j),
         "left" = c(cell$i, cell$j - 1))
}

# Action using left-hand rule
left_action <- function(cell, direction, Maze) {
  orient <- orientation(cell, direction)
  
  if (!isTRUE(orient$left) && isTRUE(orient$forward)) {
    redirect <- rotate90ccw(direction)
    new_pos <- move_forward(cell, redirect)
    
  } else if (isTRUE(orient$left) && !isTRUE(orient$forward)) {
    redirect <- direction
    new_pos <- move_forward(cell, redirect)
    
  } else if (isTRUE(orient$left) && isTRUE(orient$forward)) {
    redirect <- rotate90cw(direction)
    new_pos <- cell  # No move, rotate
    
  } else {
    redirect <- rotate90ccw(direction)
    new_pos <- move_forward(cell, redirect)
  }
  
  new_idx <- which(sapply(Maze, function(c) c$i == new_pos[1] && c$j == new_pos[2]))
  return(list(new_idx, redirect))
}

# Start and end positions
start_index2 <- which(sapply(Maze, function(cell) cell$i == 13 && cell$j == 13))
end_index2 <- which(sapply(Maze, function(cell) cell$i == 1 && cell$j == 1))

# Initialize
getOut2 <- left_action(Maze[[start_index2]], "right", Maze)
solver_left <- c(start_index2)
l <- 1

# Solving using left-hand rule
while (getOut2[[1]] != end_index2) {
  current_idx <- getOut2[[1]]
  current_dir <- getOut2[[2]]
  
  solver_left <- c(solver_left, current_idx)
  getOut2 <- left_action(Maze[[current_idx]], current_dir, Maze)
  l <- l + 1
  if (l > 10000) {
    cat("Loop limit reached. Then Maze not solved.\n")
    break
  }
}

# Add end index if reached
if (getOut2[[1]] == end_index2) {
  solver_left <- c(solver_left, end_index2)
}




# # View the final path
# print(solver_left)

# # --- Run the left-hand rule maze solver ---
# getOut <- action(Maze[[start_index]], "right", Maze)
# solver_left <- c(start_index)
# l <- 1
# 
# while (getOut[[1]] != end_index) {
#   current_idx <- getOut[[1]]
#   current_dir <- getOut[[2]]
# 
#   solver_left <- c(solver_left, current_idx)
#   getOut <- action(Maze[[current_idx]], current_dir, Maze)
# }
# 
# # Include the end position
# solver_left <- c(solver_left, end_index)
# 
# # View the final path
# print(solver_left)
# 
# head(solver_left)



#-------------------------------------------------------------------------------
# Question 3 (a)
#-------------------------------------------------------------------------------
   
#We need to first define the arguments for  the apply function
firstArgument<-strategies
secondArgument<-2  #this is only for coloums 
thirdArgument<-mean #this is for the mean
#calculating the averages of colums
column_averages <- apply(firstArgument, secondArgument, thirdArgument)
# Print the column averages
print(column_averages)


  

#-------------------------------------------------------------------------------
# Question 3 (b)
#-------------------------------------------------------------------------------

library(ggplot2)

q3b_plot <- ggplot(strategies, aes(x = `Right.hand.rule`, y = after_stat(density))) +
  geom_histogram(fill = "lightblue", color = "black") +
  geom_density() +
  labs(
    x = "Number of cells traversed",
    title = "Distribution of the number of cells traversed to solve\n 1000 randomly generated 20x20 mazes (right-hand rule)"
  ) +
  theme(plot.title = element_text(hjust = 0.5))  # Center the title

# Print the plot
#print(q3b_plot)

  
  
#-------------------------------------------------------------------------------
# Question 3 (c)
#-------------------------------------------------------------------------------
  
  colnames(strategies) <- c("Right-hand",
                            "Left-hand",
                            "Tremaux")
  
  stackdata            <- stack(strategies)
  colnames(stackdata)  <- c("Number_traversed","Strategy") 
  

  
  # Create the side-by-side box plot
  q3c_plot <- ggplot(stackdata, aes(x = Number_traversed, y = Strategy)) +
    geom_boxplot(aes(fill = Strategy)) +  # Fill by strategy
    labs(
      x = "Number of cells traversed",
      y = "Maze solver strategy",
      title = "Distribution of the number of cells traversed\n to solve 1000 randomly generated 20x20 mazes"
    ) +
    theme(plot.title = element_text(hjust = 0.5))  # Center the plot title
  
  # Display the plot
  #rint(q3d_plot)
  

 
