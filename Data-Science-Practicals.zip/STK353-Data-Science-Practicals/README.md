# STK353 Data Science Practicals (2025)

Practical assignments in R for **STK353** at the University of Pretoria, covering
simulation, data wrangling, classification on imbalanced data, clustering and text mining.

## Contents

| Practical | Topic | Methods and packages |
|---|---|---|
| [1. Maze simulation](Practical-1_Maze-Simulation) | Generating random mazes and comparing maze-solving strategies | Simulation, custom maze generator, `ggplot2` |
| [2. Audio features wrangling](Practical-2_Audio-Features-Wrangling) | Cleaning and reshaping a music audio-features dataset | `dplyr`, `tidyr` |
| [3. Imbalanced classification](Practical-3_Imbalanced-Classification) | Predicting insurance uptake when the classes are unbalanced | Oversampling, undersampling, SMOTE, decision trees, KNN, ROC/AUC (`rpart`, `caret`, `smotefamily`, `pROC`, `class`) |
| [4. Clustering and text mining](Practical-4_Clustering-and-Text-Mining) | Segmenting insurance customers; analysing short weather comments | K-means, hierarchical clustering, cluster validation (`cluster`, `clValid`); text pre-processing, word embeddings, sentiment (`tm`, `word2vec`, `syuzhet`) |

## How to run

1. Clone or download the repository.
2. In R or RStudio, set the working directory to the practical's folder, e.g.
   `setwd("Practical-1_Maze-Simulation")`. Each script reads its data from its own folder.
3. Install any missing packages, e.g.
   ```r
   install.packages(c("ggplot2", "dplyr", "tidyr", "readxl", "rpart", "caret",
                      "smotefamily", "pROC", "class", "e1071", "cluster",
                      "clValid", "tm", "word2vec", "syuzhet"))
   ```
4. Run the script (`Practical1.R`, `Practical2.R`, ...).

## Author
Tlou (Maima) Bonginkosi Fortune
