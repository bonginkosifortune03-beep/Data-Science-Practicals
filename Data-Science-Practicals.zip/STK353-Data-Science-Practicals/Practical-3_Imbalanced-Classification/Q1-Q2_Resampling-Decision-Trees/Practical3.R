#Practical3 (Q1 and Q2)
#Maima Bonginkosi Fortune


library(dplyr)
library(readxl)
library(rpart)
library(caret)
library(smotefamily)
library(pROC)

data <- read_excel("Insurance_Data_Practical.xlsx")
data$Insurance <- as.factor(data$Insurance)

#_______________________________________________________________________ 
# Question 1 (a)(i)
#_______________________________________________________________________ 

#We first need to check the class distribution
table(data$Insurance) #which shows that they are not equal

#then separete the majority and minority classes
majority_class <- data %>% filter(Insurance == "No")
minority_class <- data %>% filter(Insurance == "Yes")

#Set a seed for reproducibility
set.seed(123)
oversampled_minority <- minority_class %>% sample_n(nrow(majority_class), replace = TRUE)

#then we combine the oversampled minority class with the majority class
balanced_data_onversample <- bind_rows(oversampled_minority,majority_class)


#then we can check if they are balanced or not
table(balanced_data_onversample$Insurance)

#then we can calculate the first quantile
firstq <- quantile(balanced_data_onversample$children, 0.25)

#_______________________________________________________________________ 
# Question 1 (a)(ii)
#_______________________________________________________________________ 


#We first need to check the class distribution
table(data$Insurance) #which shows that they are not equal

#then separete the majority and minority classes
majority_class <- data %>% filter(Insurance == "No")
minority_class <- data %>% filter(Insurance == "Yes")

#Set a seed for reproducibility
set.seed(123)

undersampled_majority <- majority_class %>% sample_n(nrow(minority_class))

#then we balance the data 
#binding the undersample with the minority
balanced_data_undersample <-bind_rows(undersampled_majority, minority_class)

#then we can check if they are balanced or not
table(balanced_data_undersample$Insurance)

#then we calculate the median of the children
med <- median(balanced_data_undersample$children)

#_______________________________________________________
# Question 1(b)
#_______________________________________________________

set.seed(123)

#we need to create 5 folds for cross validation
folds <- createDataPartition(data$Insurance, p = 0.8, list = TRUE, times = 5)


# Initialize variables to store results
accuracy_scores <- numeric(length(folds))
auc_scores <- numeric(length(folds))


#then we need to perfume 5 folds cross validation
# Perform 5-fold cross-validation
for (i in 1:length(folds)) {
  # Create training and test sets
  train_indices <- folds[[i]]
  train_data <- data[train_indices, ]
  test_data <- data[-train_indices, ]
  
  # Train the logistic regression model
  model <- glm(Insurance ~ ., data = train_data, family = "binomial")
  
  # Make predictions on the test set
  predictions_prob <- predict(model, newdata = test_data, type = "response")
  predictions <- ifelse(predictions_prob > 0.5, "Yes", "No")
  
  # Calculate performance metrics
  confusion_matrix <- confusionMatrix(as.factor(predictions), as.factor(test_data$Insurance))
  
  # Extract accuracy
  accuracy <- confusion_matrix$overall['Accuracy']
  
  # Calculate AUC
  roc_curve <- roc(test_data$Insurance, predictions_prob)
  auc_value <- auc(roc_curve)
  
  # Store the results
  accuracy_scores[i] <- accuracy
  #[i] <- auc_value
} # end of the loop

accuracylogistic <- mean(accuracy_scores)

accuracylogistic

#_______________________________________________________________________ 
# Question 2(a)
#_______________________________________________________________________ 

X <-data[,-1]
Y <-data$Insurance #for the targer variable

set.seed(123)
#Apply the SMOTE
smote_result <- SMOTE(X, Y, K = 5, dup_size = 2)


#get the balanced dataset
balance_data_smote <- smote_result$data

balance_data_smote$Insurance <- smote_result$class

#calculating the meanchild
meanchild <- mean(balance_data_smote$children)
meanchild


#_______________________________________________________________________ 
# Question 2(b)
#_______________________________________________________________________ 
set.seed(123)  # Ensure reproducibility
train_index <- createDataPartition(balance_data_smote$class, p = 0.8, list = FALSE)
train_data <- balance_data_smote[train_index, ]
test_data <- balance_data_smote[-train_index, ]

# Train a Decision Tree model using rpart()
model_tree <- rpart(class ~ ., data = train_data, method = "class")

#Then we need to make predictions 
predictions_prob_tree <- predict(model_tree, newdata = test_data, type = "prob")[,2]

#then create a confusion matrix 
predictions_tree <- ifelse(predictions_prob_tree > 0.5, "Yes", "No")
confusion_matrix_tree <- confusionMatrix(as.factor(predictions_tree), as.factor(test_data$class))

# Extract the 2x2 confusion matrix
confusiontree <- confusion_matrix_tree$table
confusiontree

#_______________________________________________________________________ 
# Question 2 (c)
#_______________________________________________________________________ 
#getting the precision
precisiontree <- confusion_matrix_tree$byClass["Pos Pred Value"]

