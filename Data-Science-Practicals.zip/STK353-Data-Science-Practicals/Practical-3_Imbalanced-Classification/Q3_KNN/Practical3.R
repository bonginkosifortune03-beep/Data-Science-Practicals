
library(readxl)
library(class)
library(caret)
library(e1071)



binary <- read_excel("Insurance_Data_Practical.xlsx")
binary$Insurance <- as.factor(binary$Insurance)

#______________________________________________________________________ 
# - Each call to test_that() produces one test
# - Each test represents one point value
# - You can have multiple tests for each question
#_______________________________________________________________________

# We need to load the Pima Insurance dataset;
#______________________________________________________________________ 
# Question 3 (a)
#_______________________________________________________________________ 

set.seed(123)
train_index <- createDataPartition(binary$Insurance, p= 0.8 , list =FALSE) #creating partitions
train_data <- binary[train_index,]
test_data <- binary[-train_index,]

#then we need to scale the features for the categorical use encoding
train_scaled <- train_data[, -which(names(train_data) == "Insurance")]  #this exclude the target
test_scaled <- test_data[, -which(names(test_data) == "Insurance")]     #this exclusde the target variable

head(train_scaled)

#which we then need to train the model using KNN model

k_value <- 5 # 5 given on the question;
predictions_knn <- knn( train = train_scaled,
                        test = test_scaled,
                        cl = train_data$Insurance,
                        k = k_value)

#then get the number of "Yes"
yescount <- sum(predictions_knn == "Yes")
yescount


#_______________________________________________________________________ 
# Question 3 (b)
#_______________________________________________________________________ 

#for the recall we need to have confusion matrix first
confusiobMatrix_knn <- confusionMatrix(as.factor(predictions_knn), as.factor(test_data$Insurance))
recallknn <- confusiobMatrix_knn$byClass['Sensitivity']
recallknn


#_______________________________________________________________________ 
# Question 3 (c)
#_______________________________________________________________________ 

#using the Naive baise to get the predicted probabilirties
model_nb <- naiveBayes(Insurance ~ . , data = train_data)

#calculating the prior probabilities;
priornb <- as.vector(model_nb$apriori/sum(model_nb$apriori))



#_______________________________________________________________________ 
# Question 3 (d)
#_______________________________________________________________________ 

#calculating the prediction mean
predictions_prob_nb <- predict(model_nb, newdata = test_data, type = "raw")

#getting the probabilities for the "YES"
probility_yes <- predictions_prob_nb[ ,"Yes"]

#getting the means of those probability;
probmeannb <- mean(probility_yes)
probmeannb


