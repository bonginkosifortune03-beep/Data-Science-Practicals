# Load required packages
library(tm)
library(word2vec)
library(syuzhet)

# Set seed for reproducibility
set.seed(123)

# Define the comments as a vector
comments <- c("The sun is shining brightly today, it is a perfect day for a walk.",
              "It is been raining non-stop for 3 days, and everything is soaked.",
              "The chilly wind made it hard to stay outside for long.",
              "A thick layer of fog covered the town this morning, it is hard to see the roads.",
              "The heatwave is unbearable, and everyone is trying to stay cool indoors.",
              "The snow turned the entire city into a winter wonderland.",
              "The clear blue sky made for a beautiful afternoon by the lake.",
              "Thunderstorms are expected tonight, so we should probably stay indoors.",
              "The humidity today is making it feel much hotter than it actually is.",
              "A gentle breeze made the warm afternoon feel comfortable and pleasant.",
              "The sudden hailstorm caught us by surprise while we were outside.",
              "The crisp autumn air and falling leaves make this my favorite time of year.",
              "The weather forecast says it is going to be sunny and warm all week long.",
              "We had to cancel our plans because of the unexpected snowstorm.",
              "It was a perfect evening with a stunning sunset and cool, refreshing air.")

corpus <- Corpus(VectorSource(comments))

###### pre-processing ######

corpus <- tm_map(corpus, content_transformer(tolower))

corpus <- tm_map(corpus, removePunctuation)

corpus <- tm_map(corpus, removeNumbers)

corpus <- tm_map(corpus, removeWords, stopwords("english"))

corpus <- tm_map(corpus, stripWhitespace)


# Q1
# Create Document-Term Matrix
dtm <- DocumentTermMatrix(corpus)
dtm_matrix <- as.matrix(dtm)


#Q2
# Create TF-IDF matrix
tfidf <- weightTfIdf(dtm)
tfidf_matrix<-as.matrix(tfidf)


#Q3
# Calculate the column means
tfidf_col_means <- colMeans(tfidf_matrix)

# Extract the importance score for "sunny"
sunny_importance <- tfidf_col_means["sunny"]


#Q4
# Convert the corpus to a character vector for Word2Vec training
cleaned_comments <- sapply(corpus, as.character)

# Save the cleaned comments as a text file for Word2Vec training
writeLines(cleaned_comments, "cleaned_comments.txt")

# Train a Word2Vec model using the skip-gram algorithm (you can switch to 'cbow' if needed)
word2vec_model <- word2vec("cleaned_comments.txt", type = "skip-gram", dim = 10, iter = 1, window = 5, min_count = 2)

# Retrieve vector for "feel"
feel_vector <- predict(word2vec_model, "feel", type = "embedding")


#Q5
# Find similar words
similar_words <- predict(word2vec_model, newdata = "cool", type = "nearest", top_n = 1)
similar_cool <- as.data.frame(similar_words)


#Q6
sentiment_scores <- get_nrc_sentiment(cleaned_comments)

positive_negative_scores <- sentiment_scores[, c("positive", "negative")]

neutral_scores <- ifelse(rowSums(positive_negative_scores) == 0, 1, 0)

sentiment_scores$neutral <- neutral_scores
positive_negative_neutral <- colSums(sentiment_scores[, c("positive", "negative", "neutral")])