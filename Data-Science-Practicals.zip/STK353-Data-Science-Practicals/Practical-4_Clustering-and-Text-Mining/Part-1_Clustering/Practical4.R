library(cluster)
library(clValid)
library(readxl)

data <- read_excel("Insurance_Data_Practical4.xlsx")

#Question 1
#K-means clustering for the first 100 rows:

#Subset the first 100 rows
subset_data <- data[1:100,]

#Apply k-means clustering with k = 3, nstart=10
set.seed(123) #ensure reproducibility
kmeans_result <- kmeans(subset_data, centers = 3, nstart = 10)

#Add the cluster assignments to the dataset
subset_data$cluster <- kmeans_result$cluster

#view the updated dataset
head(subset_data)


# Q1(a)
sizekmean <-kmeans_result$size


# Q1(b)
withinsskmean <-kmeans_result$withinss


# Q1(c)
betweensskmean <- kmeans_result$betweenss


# Q1(d)
meanagekmean <- tapply(subset_data$Age,subset_data$cluster, mean)


# Q1(e)
medianchildkmean <- tapply(subset_data$children, subset_data$cluster, median)


# Q1(f)
dunnkmean <- dunn(clusters = subset_data$cluster, Data = subset_data)


# Q2
wsskmean <- numeric()

# Loop through different K values (2 to 5)
for (k in 2:5) {
  # Apply K-means clustering with the current value of K
  kmeans_result <- kmeans(subset_data, centers = k, nstart = 10)
  
  # Store the total within-cluster sum of squares for the current K in the vector
  wsskmean[k - 1] <- sum(kmeans_result$withinss)
}

#Question 3
#Agglomerative hierarchical clustering using Euclidean distance

#subset the first 35 rows 
sub_data <- data[1:35,]

#Compute the distance matrix
dist_matrix <- dist(sub_data, method = "euclidean")

#perform hierarchical clustering using complete linkage
hc <- hclust(dist_matrix, method = "complete")

#cut the dendrogram to form clusters
k <- 3 #No. of clusters
clusters <- cutree(hc, k)

#Add cluster assignments to the original data
sub_data$cluster <- as.factor(clusters)


#Q3(a)
#Calculate the size of each cluster
sizeagg <- as.vector(table(sub_data$cluster))


#Q3(b)
#Calculate the mean age for each cluster
meanageagg <- aggregate(Age ~ clusters, data = sub_data, FUN = mean)
meanageagg_vector <- meanageagg$Age 


#Q3(c)
#Calculate the Dunn index for the hierarchical clustering
dunnagg <- dunn(clusters = clusters, Data = sub_data[, -ncol(sub_data)])