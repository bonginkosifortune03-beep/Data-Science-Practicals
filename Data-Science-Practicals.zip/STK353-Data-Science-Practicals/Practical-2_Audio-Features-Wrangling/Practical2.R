#-------------------------------------------------------------------------------
# Load the required R package(s).
#-------------------------------------------------------------------------------

  library(tidyr)
  library(dplyr)

#-------------------------------------------------------------------------------
# Import the audio_features.csv file into R.
#-------------------------------------------------------------------------------
  
  audio_features <- read.csv("audio_features.csv")

#-------------------------------------------------------------------------------
# Question 1(a)
#-------------------------------------------------------------------------------
  #creating variable called "Key"
  audio_features <- audio_features %>%
    mutate(keys = case_when(
      !is.na(A) ~ 9,
      !is.na(A_sharp) ~ 10,
      !is.na(B) ~ 11,
      !is.na(C) ~ 0,
      !is.na(C_sharp) ~ 1,
      !is.na(D) ~ 2,
      !is.na(D_sharp) ~ 3,
      !is.na(E) ~ 4,
      !is.na(F) ~ 5,
      !is.na(F_sharp) ~ 6,
      !is.na(G) ~ 7,
      !is.na(G_sharp) ~ 8
    ))
  
  #removing unnesseary column A to G_sharp
  tidy1 <- audio_features %>%
    select(-A, -A_sharp, -B, -C, -C_sharp, -D, -D_sharp, -E, -F, -F_sharp, -G, -G_sharp)
  
  #convert to tibble 
  tidy1 <- as_tibble(tidy1)
  


#-------------------------------------------------------------------------------
# Question 1(b)
#-------------------------------------------------------------------------------
  #removing duplicates
  tidy2 <- unique(tidy1)

  
  
  

#-------------------------------------------------------------------------------
# Question 1(c)
#-------------------------------------------------------------------------------
#removing missing values
tidy3 <- na.omit(tidy2)

  
  
  
  
#-------------------------------------------------------------------------------
# Question 2(a)
#-------------------------------------------------------------------------------
  F_w <- Vectorize(function(w){
    ifelse(w < 0, 0, 1 - 1/(1 + w^2))
  })
  

  

#-------------------------------------------------------------------------------
# Question 2(b)
#-------------------------------------------------------------------------------
  Q_u <- function(w) {
    # Propagate NA inputs and enforce domain
    out <- ifelse(w < 0 | w >= 1, NA, sqrt(w / (1 - w)))
    return(out)
  }
  
  Q_u(0.5)
  
    
#-------------------------------------------------------------------------------
# Question 2(c)
#-------------------------------------------------------------------------------
  
  set.seed(96)
  u_vals <- runif(10000, min = 0, max = 1)
  #applying the
  pit_sample <- Q_u(u_vals)
  


  
#-------------------------------------------------------------------------------
# Question 2(d)
#-------------------------------------------------------------------------------
  
  #Getting the PDF of W
  f_w <- function(w) {
    ifelse(w < 0, 0, 2*w / (1 + w^2)^2)
  }
  
  # using optimize to maximise f(w) on [0.5, 1.5]
  max_f <- optimize(f_w, interval = c(0.5, 1.5), maximum = TRUE)$objective
  
  
  set.seed(47)
  
  n <- 10000
  x <- runif(n, min = 0.5, max = 1.5)
  y <- runif(n, min = 0, max = max_f)
   
  # getting the hits which are points under f(x)
  hits <- sum(y <= f_w(x))
  
  # probability estimate = area of rectangle * fraction of hits
  prob_w <- (1.5 - 0.5) * max_f * (hits / n)
  
  #prob_w
  
  
  
#-------------------------------------------------------------------------------
# Question 3(a)
#-------------------------------------------------------------------------------

  #Getting the targrt density 
  f_x <- function(x) {
    inside <- (x >= 0 & x <= 5)
    out <- numeric(length(x))
    out[inside] <- (400/769) * exp(-0.5 * x[inside]^2 * sin(x[inside])^2) * log(x[inside] + 1)
    out
  }

  #finding the maximus using the opitmize function
  M <- optimize(f_x, interval = c(0, 5), maximum = TRUE)$objective
  
  
  #doing the acceptance -rejection using the uniform proposal
  #using simulation
  set.seed(85)
  n <- 10000
  
  x_prop <- runif(n, min = 0, max = 5)     # proposal samples (g is Uniform(0,5))
  u      <- runif(n)                       # uniforms for accept/reject
  
  # Accept if u <= f(x) / M
  accept <- u <= f_x(x_prop) / M
  ar_sample <- x_prop[accept]
  
  
#-------------------------------------------------------------------------------
# Question 3(b)
#-------------------------------------------------------------------------------
  f_x <- function(x) {
    inside <- (x >= 0 & x <= 5)
    out <- numeric(length(x))
    out[inside] <- (400/769) * exp(-0.5 * x[inside]^2 * sin(x[inside])^2) * log(x[inside] + 1)
    out
  }
  
  #intergrating the expected value of X;
  h <- function(x) x * f_x(x)
  #calculating the maximising  function using the optimize;
  M_h <- optimize(h, interval = c(0, 5), maximum = TRUE)$objective
  
  
  #doing the simulation for Hit or miss MoNTE Carlo for the mean
  
  set.seed(74)
  n <- 10000            #number of sample
  xu <- runif(n, 0, 5)  #using the ran uniform 
  yu <- runif(n, 0, M_h)
  
  
  #getting the points under the function 
  hits <- yu <= h(xu)
  
  #then calculating the expected value estimete
  exp_x <- (5 - 0) * M_h * mean(hits)
  
  
#-------------------------------------------------------------------------------
# Question 3(c)
#-------------------------------------------------------------------------------
  
  set.seed(63)
  
  B <- 200
  n <- length(ar_sample)
  xbar_boot <- replicate(B, mean(sample(ar_sample, size = n, replace = TRUE)))
  
  
  
  
  
#-------------------------------------------------------------------------------
# Question 3(d)
#-------------------------------------------------------------------------------
  alpha <- 0.10  #90% confidencen interval
  # 5th percentile
  boot_lower <- unname(quantile(xbar_boot, probs = alpha/2)) 
  # 95th percentile
  boot_upper <- unname(quantile(xbar_boot, probs = 1 - alpha/2))
  
  